package com.sample.code;

import com.google.gson.JsonObject;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;

@WebServlet(name = "SampleServlet", value = "/SampleServlet")
public class SampleServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String emailContent = request.getParameter("email");
        Session s = Session.getInstance(new Properties());
        InputStream is = new ByteArrayInputStream(emailContent.getBytes());
        try {
            MimeMessage message = new MimeMessage(s, is);
            JsonObject object = new JsonObject();
            Address[] toAddress = message.getRecipients(Message.RecipientType.TO);
            if (toAddress != null && toAddress.length > 0) {
                if (toAddress.length == 1) {
                    object.addProperty("To", toAddress[0].toString());
                } else {
                    object.addProperty("To", Arrays.toString(toAddress));
                }
            } else {
                object.addProperty("To", "");
            }
            object.addProperty("From", String.valueOf(message.getFrom()[0]));
            object.addProperty("Date", message.getSentDate().toString());
            object.addProperty("Subject", message.getSubject());
            object.addProperty("Message-ID", message.getMessageID());

            response.setContentType("application/json");
            response.setStatus(200);
            response.getWriter().write(object.toString());
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

}
